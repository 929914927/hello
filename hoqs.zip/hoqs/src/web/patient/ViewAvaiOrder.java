package web.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tools.DBTools;
import tools.DtoTools;

@WebServlet("/ViewAvaiOrder")
public class ViewAvaiOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		//HttpSession session = request.getSession();
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		Object zhicheng = dto.get("zhicheng");
		Object name = dto.get("name");
		Object keshi = dto.get("keshi");
		List<Object> params = new ArrayList<>();
		int flag;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("select id,name,title,department from doctor ")
					.append(" where 1=1 ");
			pstm = conn.prepareStatement(sql.toString());
			//���sql��ƴ��
			if(zhicheng != null && !zhicheng.equals(""))
			{
				sql.append(" and phone=?");
				params.add(zhicheng);
			}
			if(name != null && !name.equals(""))
			{
				sql.append(" and name=?");
				params.add(name);
			}
			if(keshi != null && !keshi.equals(""))
			{
				sql.append(" and name=?");
				params.add(keshi);
			}
			int index = 1;
			for(Object e:params)
			{
				pstm.setObject(index++, e);
			}
			rs = pstm.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			ArrayList<Map<String,String>> rows = new ArrayList<>();
			Map<String,String>ins = null;
			while(rs.next())
			{
				ins = new HashMap<>();
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
					System.out.println(rs.getString(i));
				}
				rows.add(ins);
			}
			if(rows.size()>0)
			{
				request.setAttribute("rows", rows);
			}
			else
			{
				request.setAttribute("msg", "û�з���������ҽ����");
			}
			
			request.getRequestDispatcher("order.jsp").forward(request, response);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
