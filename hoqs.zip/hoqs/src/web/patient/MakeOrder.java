package web.patient;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tools.DBTools;
import tools.DtoTools;

@WebServlet("/MakeOrder")
public class MakeOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		//URL url = new URL();
		//String queryStr = request.getQueryString();
		//System.out.println(queryStr);
		HttpSession session = request.getSession();
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		//Object use = dto.get("use");
		//Object name = dto.get("name");
		//List<Object> params = new ArrayList<>();
		int flag=0,flag2=0;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("select x.id,x.appo_num,x.curr_appo_num,y.name")
					.append(" from work x, doctor y")
					.append(" where y.id=? and x.doctor_id = y.id");
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, dto.get("id"));
			System.out.println("----"+dto.get("id")+ "+++" +session.getAttribute("useid"));
			rs = pstm.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			Map<String,String>ins = new HashMap<>();
			if(rs.next())
			{
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
				}
			}
			int t1 = Integer.parseInt(ins.get("curr_appo_num"));
			int t2 = Integer.parseInt(ins.get("appo_num"));
			if(t1 + 1 <= t2)
			{
				//�޸�ҽ����ǰԤԼ��
				StringBuilder sql2 = new StringBuilder()
						.append("update work ")
						.append(" set curr_appo_num=? ")
						.append(" where id=?");
				DBTools.close(pstm);
				pstm=conn.prepareStatement(sql2.toString());
				
				Object tmp =(Object)(t1+1);
				pstm.setObject(1, tmp);
				//System.out.println("curr:"+ins.get("curr_appo_num")+" curr+1:"+tmp);
				pstm.setObject(2, dto.get("id"));
				flag = pstm.executeUpdate();
				
				//����ԤԼ��
				StringBuilder sql3 = new StringBuilder()
						.append("insert into appointment(time,patient_id,doctor_id,doctor_name)")
						.append(" values(?,?,?,?)");
				pstm = conn.prepareStatement(sql3.toString());
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
				String date = sdf.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ�䣬Ҳ��ʹ�õ�ǰʱ���
				pstm.setObject(1, date);
				pstm.setObject(2, session.getAttribute("useid"));
				pstm.setObject(3, dto.get("id"));
				pstm.setObject(4, ins.get("name"));
				flag2=pstm.executeUpdate();
			}
			if(flag>0&&flag2>0)
			{
				request.setAttribute("msg", "ԤԼ�ɹ���");
				
			}
			else
			{
				request.setAttribute("msg", "ԤԼʧ�ܣ���ҽ����Լ����");
			}
			request.getRequestDispatcher("order.jsp").forward(request, response);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
