package web.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tools.DBTools;
import tools.DtoTools;


@WebServlet("/InfoUpdServlet")
public class InfoUpdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		HttpSession session = request.getSession();
		int flag;
		try {
			conn = DBTools.getConnection();
			
			StringBuilder sql = new StringBuilder()
					.append("update patient ")
					.append(" set phone=?,name=?,sex=?,age=?,birth=?")
					.append(" where id=?");
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, dto.get("use"));
			pstm.setObject(2, dto.get("name"));
			pstm.setObject(3, dto.get("sex"));
			pstm.setObject(4, dto.get("age"));
			pstm.setObject(5, dto.get("birth"));
			pstm.setObject(6, session.getAttribute("useid"));
			flag = pstm.executeUpdate();
			if(flag>0)
				request.setAttribute("msg", "��Ϣ�޸ĳɹ���");
			else
				request.setAttribute("msg", "��Ϣ�޸�ʧ�ܣ�");
			request.getRequestDispatcher("patientinfo.jsp").forward(request, response);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);		
		}
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
