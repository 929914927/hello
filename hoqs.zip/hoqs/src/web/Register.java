package web;

import tools.DBTools;
import tools.DtoTools;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Register() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int flag;
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		int usetype = Integer.parseInt(dto.get("usetype").toString());
		if(usetype == 2)
		{
			/**
			 * �������ݿ�
			 */
			Connection conn = null;
			PreparedStatement pstm = null;
			try {
				conn = DBTools.getConnection();
				StringBuilder sql = new StringBuilder()
						.append("insert into patient(phone,password,name,sex,birth,age)")
						.append(" values(?,?,?,?,?,?)");
				pstm = conn.prepareStatement(sql.toString());
				pstm.setObject(1, dto.get("use"));
				pstm.setObject(2, dto.get("password"));
				System.out.println(dto.get("password"));
				pstm.setObject(3, dto.get("name"));
				pstm.setObject(4, dto.get("sex"));
				pstm.setObject(5, dto.get("birth"));
				pstm.setObject(6, dto.get("age"));
				flag = pstm.executeUpdate();
				
				request.setAttribute("msg", "����" + (flag>0?"�ɹ���":"������ϣ�"));
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}catch(SQLException ex) {
				request.setAttribute("msg", "����ʧ�ܣ����û��Ѵ��ڣ�");
				request.getRequestDispatcher("doctAdd.jsp").forward(request, response);
			}catch(Exception ex) {
				ex.printStackTrace();
			}finally {
				DBTools.close(pstm);
				DBTools.close(conn);
			}
			
		}
		else
		{
			request.setAttribute("msg", "��Ǹ����û��ע��Ȩ�ޣ�");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
