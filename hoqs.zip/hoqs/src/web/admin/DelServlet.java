package web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tools.DBTools;
import tools.DtoTools;


@WebServlet("/DelServlet")
public class DelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		//HttpSession session = request.getSession();
		//System.out.println("+++" + session.getAttribute("did") + "+++");
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		System.out.println(dto);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		int flag;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("delete  from doctor where id=?");
			pstm = conn.prepareStatement(sql.toString());
			//System.out.println("attribute"+request.getAttribute("did"));
			pstm.setObject(1, dto.get("did"));
			//System.out.println("dto" +dto.get("did"));
			flag = pstm.executeUpdate();
			if(flag > 0)
			{
				request.setAttribute("msg", "ɾ���ɹ���");
			}
			else
				request.setAttribute("msg", "ɾ��ʧ�ܣ�");
			/**
			 * ɾ�����ز�
			 */
			
			DBTools.close(pstm);
			StringBuilder sql2 = new StringBuilder()
					.append("select id,phone,name,title,department ")
					.append(" from doctor ");
			//System.out.println(sql2);
			pstm = conn.prepareStatement(sql2.toString());
			rs = pstm.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			ArrayList<Map<String,String>> rows = new ArrayList<>();
			Map<String,String>ins = null;
			while(rs.next())
			{
				ins = new HashMap<>();
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
					//System.out.println(rs.getString(i));
				}
				rows.add(ins);
			}
			request.setAttribute("rows", rows);
			request.getRequestDispatcher("doctManage.jsp").forward(request, response);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(pstm);
			DBTools.close(conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
