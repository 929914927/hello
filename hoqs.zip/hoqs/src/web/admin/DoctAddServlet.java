package web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tools.DBTools;
import tools.DtoTools;

@WebServlet("/DoctAddServlet")
public class DoctAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int flag;
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		request.setCharacterEncoding("utf-8");
		dto = dtotools.createDto(request);
		System.out.println(dto);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("insert into doctor(phone,password,name,title,")
					.append(                   "department,sex,birth,age)")
					.append(" values(?,?,?,?,?,?,?,?)");
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, dto.get("use"));
			pstm.setObject(2, dto.get("password"));
			
			pstm.setObject(3, dto.get("name"));
			pstm.setObject(4, dto.get("zhicheng"));
			pstm.setObject(5, dto.get("bumen"));
			pstm.setObject(6, dto.get("sex"));
			pstm.setObject(7, dto.get("birth"));
			pstm.setObject(8, dto.get("age"));
			flag = pstm.executeUpdate();
			
			request.setAttribute("msg", "����" + (flag>0?"�ɹ���":"������ϣ�"));
			request.getRequestDispatcher("doctAdd.jsp").forward(request, response);
		}catch(SQLException ex) {
			request.setAttribute("msg", "����ʧ�ܣ����û��Ѵ��ڣ�");
			request.getRequestDispatcher("doctAdd.jsp").forward(request, response);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(pstm);
			DBTools.close(conn);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
