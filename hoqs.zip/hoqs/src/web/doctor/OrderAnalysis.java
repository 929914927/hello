package web.doctor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class OrderAnalysis {
	
	public static void main(String[] args) throws Exception
	{
		
		/*
		//�ļ��洢
		FileOutputStream fop = null;
		File file;
		int a[] = {1,2,3,4,5,6,7,8,9,10};
		
		try {
			//��ʱ����d��
			file = new File("d:/data.txt");
			fop = new FileOutputStream(file);
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fop,"utf-8"));
			// if file exists, then delete it
			if(file.exists())
				file.delete();
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			
			// get the content in bytes
			//byte[] contentInBytes = content.getBytes();
			for(int i = 0; i < 10; i ++)
			{
				writer.write(a[i]);
				//fop.write(a[i]);
				//fop.write('\b');
			}
			writer.flush();
			writer.close();
			//fop.flush();
			//fop.close();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fop != null) {
					fop.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		*/
		
		
		
		/*
		 //�ַ���ת����
		SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		Date date1 = null;
		date1 = sdf.parse("2018-07-07 8:41:00");
		System.out.println(date1);
		
		List<Object> params = new ArrayList<>();
		System.out.println(params);
		*/
		
		/*
		 //������������֮��ĳ���
		SimpleDateFormat format = new  SimpleDateFormat("yyyy-MM-dd" );  
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String str2 = sc.nextLine();
		Date date1 = new Date();
		Date date2 = new Date();
		date1 = format.parse(str);
		date2 = format.parse(str2);
		long daynum = (date2.getTime() - date1.getTime())/(24*3600*1000);
		daynum = Math.abs(daynum);
		//int t = dayForWeek(str);
		System.out.println(daynum);
		*/
		
		/*
		//���ڼ�1����
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		date = sdf.parse("1997-03-15");
		Calendar calendar=Calendar.getInstance();   
		   calendar.setTime(date); 
		   System.out.println(calendar.get(Calendar.DAY_OF_MONTH));//��������� 
		   calendar.set(Calendar.DAY_OF_MONTH,calendar.get(Calendar.DAY_OF_MONTH)+16);//�����ڼ�1  
		   System.out.println(calendar.getTime());//��1֮�������Top 
		  */ 
		
		
		/*
		//��ȡ���ڵ�������
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		date = sdf.parse("1997-02-15");
		System.out.println(date);
		Calendar calendar = Calendar.getInstance();  
		calendar.setTime(date);
		System.out.println("��: " + calendar.get(Calendar.YEAR));  
		System.out.println("��: " + (calendar.get(Calendar.MONTH) + 1) + "");  
		System.out.println("��: " + calendar.get(Calendar.DAY_OF_MONTH));  
		System.out.println("ʱ: " + calendar.get(Calendar.HOUR_OF_DAY));  
		System.out.println("��: " + calendar.get(Calendar.MINUTE));  
		System.out.println("��: " + calendar.get(Calendar.SECOND));  
		System.out.println("��ǰʱ���������" + calendar.getTimeInMillis());  
		System.out.println(calendar.getTime());  
		*/
	}
	public  static  int  dayForWeek(String pTime) throws  Throwable {  
		
		SimpleDateFormat format = new  SimpleDateFormat("yyyy/MM/dd" );  
		 Calendar c = Calendar.getInstance();  
		 c.setTime(format.parse(pTime));  
		 int  dayForWeek = 0 ;  
		 if (c.get(Calendar.DAY_OF_WEEK) == 1 ){  
		  dayForWeek = 7 ;  
		 }else {  
		  dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1 ;  
		 }  
		 return  dayForWeek;
	}
	

}