package web.doctor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tools.DBTools;
import tools.DtoTools;


@WebServlet("/DocInfoUpdServlet")
public class DocInfoUpdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		HttpSession session = request.getSession();
		int flag1, flag2;
		try {
			conn = DBTools.getConnection();
			
			StringBuilder sql = new StringBuilder()
					.append("update doctor ")
					.append(" set phone=?,name=?,title=?,department=?,sex=?,age=?,birth=?")
					.append(" where id=?");
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, dto.get("use"));
			pstm.setObject(2, dto.get("name"));
			pstm.setObject(3, dto.get("zhicheng"));
			pstm.setObject(4, dto.get("keshi"));
			pstm.setObject(5, dto.get("sex"));
			pstm.setObject(6, dto.get("age"));
			pstm.setObject(7, dto.get("birth"));
			pstm.setObject(8, session.getAttribute("useid"));
			flag1 = pstm.executeUpdate();
			
			StringBuilder sql2 = new StringBuilder()
					.append("update work ")
					.append(" set worktime_start=?,worktime_end=?,appo_num=?")
					.append(" where doctor_id=?");
			DBTools.close(pstm);
			pstm = conn.prepareStatement(sql2.toString());
			
			//�ַ�������ת��
			String sbtime = dto.get("workstart").toString();
			String setime = dto.get("workend").toString();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
			Time btime = new Time(sdf.parse(sbtime).getTime());
			Time etime = new Time(sdf.parse(setime).getTime());
			
			pstm.setObject(1, btime);
			pstm.setObject(2, etime);
			pstm.setObject(3, dto.get("maxoppo"));
			pstm.setObject(4, session.getAttribute("useid"));
			flag2= pstm.executeUpdate();
			
			if(flag1>0 && flag2>0)
				request.setAttribute("msg", "��Ϣ�޸ĳɹ���");
			else
				request.setAttribute("msg", "��Ϣ�޸�ʧ�ܣ�");
			request.getRequestDispatcher("doctorinfo.jsp").forward(request, response);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);		
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
