package web.doctor;

import tools.DBTools;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.Map;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DocInfoServlet")
public class DocInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * �������ݿ�
		 * ��ѯ��һ
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		HttpSession session = request.getSession();
		
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("select * from doctor")
					.append(" where id = ?");
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, session.getAttribute("useid"));
			rs = pstm.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			Map<String, String>ins = new HashMap<>();
			if(rs.next())
			{
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
					System.out.println(rs.getString(i));
				}
			}
			/**
			 * ��ѯ����
			 */
			DBTools.close(pstm);
			DBTools.close(rs);
			StringBuilder sql2 = new StringBuilder()
					.append("select * from work")
					.append(" where doctor_id = ?");
			pstm = conn.prepareStatement(sql2.toString());
			pstm.setObject(1, session.getAttribute("useid"));
			rs =pstm.executeQuery();
			rsmd = rs.getMetaData();
			count = rsmd.getColumnCount();
			if(rs.next())
			{
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
					System.out.println(rs.getString(i));
				}
			}
			/**
			 * ���ؽ��
			 */
			if(ins.size()>0)
			{
				request.setAttribute("ins", ins);	
			}
			else
			{
				request.setAttribute("msg", "������ϣ�");
			}
			request.getRequestDispatcher("doctorinfo.jsp").forward(request, response);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
