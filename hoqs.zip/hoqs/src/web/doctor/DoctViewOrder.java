package web.doctor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tools.DBTools;
import tools.DtoTools;

@WebServlet("/DoctViewOrder")
public class DoctViewOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		HttpSession session = request.getSession();
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		System.out.println(dto);
		Object btime = dto.get("btime");
		
		Object etime = dto.get("etime");
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		//���������ʹ��������ʽ
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal =Calendar.getInstance();
		
		List<Object>params = new ArrayList<>();
		int flag;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder()
					.append("select x.patient_id,y.name,x.time")
					.append(" from appointment x,patient y ")
					.append(" where doctor_id=? and x.patient_id=y.id");
					
			//���sql��ƴ��
			params.add(session.getAttribute("useid"));
			//System.out.println(session.getAttribute("useid"));
			
		
			//���Ӳ�ѯ������������ֹ����ͬʱ����
			if(btime != null && !btime.equals("") && etime != null && !etime.equals(""))
			{
				sql.append(" and x.time >=? and x.time <=?");
				System.out.println(etime);
				Date tmpdate = new Date();
				tmpdate = sdf.parse(etime.toString());
				cal.setTime(tmpdate);
				cal.set(cal.DAY_OF_MONTH, cal.get(cal.DAY_OF_MONTH) + 1);
				int y,m,d;
				y = cal.get(Calendar.YEAR);
				m = cal.get(Calendar.MONTH) + 1;
				d = cal.get(Calendar.DAY_OF_MONTH);
				String str = y + "-" + m + "-" + d;
				etime = (Object)str;
				System.out.println(etime);
				params.add(btime);
				params.add(etime);
			}
			pstm = conn.prepareStatement(sql.toString());	
			//��ֵ
			int index = 1;
			for(Object e:params)
			{
				pstm.setObject(index++, e);
			}
			
			rs = pstm.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			ArrayList<Map<String,String>> rows = new ArrayList<>();
			Map<String,String>ins = null;
			//���ݿ������е����ڴ�������date3
			List<Date> date3 = new ArrayList<>();
			
			while(rs.next())
			{
				ins = new HashMap<>();
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
					
				}
				date3.add(sdf.parse(ins.get("time")));
				
				rows.add(ins);
			}
			if(rows.size()>0)
			{
				request.setAttribute("rows", rows);
			}
			else
			{
				request.setAttribute("msg", "��ǰ��ԤԼ��");
			}
			/**
			 * ԤԼ���ݷ���
			 */
			
			
			
			//���в�ѯ����ʱ��ѯ
			if( (btime!=null&&!btime.equals("")) && (etime!=null&&!etime.equals("")) )
			{
				Date date1 = new Date();
				//���mysql������<=�Ƚ�ʱ���Ĵ���
				date1 = sdf.parse(btime.toString());
				System.out.println(date1);
				//��ֹ����date2����Date
				Date date2 = new Date();
				date2 = sdf.parse(etime.toString());
				
				//daynum2:�������,����Ӧ��=b-a+1�������ڴ�����ֹ����ʱ�Ѿ���һ����
				long daynum = (date2.getTime() - date1.getTime())/(24*3600*1000);
				int daynum2 = (int)Math.abs(daynum);
				System.out.println(daynum2);
				//a[]:ÿ���ԤԼ��
				int[] a = new int[daynum2 + 1];
				
				//��ѯ�����ڶ�
				String[] date4 = new String[daynum2];
				
				//ѭ���Ƚ����ݿ������鵱ǰ�����Ƿ���ȣ�����ȣ����ۼ�date1��ʼֵΪ��ʼ����
				Calendar cal2 =Calendar.getInstance();
				cal.setTime(date1);
				for(int i = 0; i < daynum2; i ++)
				{
					int yd1 = cal.get(Calendar.YEAR);
					int md1 = cal.get(Calendar.MONTH) + 1;
					int dd1 = cal.get(Calendar.DAY_OF_MONTH);
					
					
					for(Date d:date3)
					{
						
						cal2.setTime(d);
						int yd = cal2.get(Calendar.YEAR);
						int md = cal2.get(Calendar.MONTH)+1;
						int dd = cal2.get(Calendar.DAY_OF_MONTH);
						//System.out.println(d);
						System.out.println(yd1+ ":" +yd+ " " +md1+ ":" +md+ " " +dd1+ ":" +dd);
						if(yd1 == yd && md1 == md && dd1 == dd)
						{
							a[i] ++;
						}
					}
					//����ǰ����ѭ����������date4
					date4[i] = parseToNormalTime(cal.getTime());
					//ate4.add((Object)str);
					//�����ڼ�1
					cal.set(cal.DAY_OF_MONTH, cal.get(cal.DAY_OF_MONTH) + 1);
					//System.out.println(cal.getTime());
				}
				
				//����
				String[] tmpstr = new String[daynum2];
				for(int i = 0; i < daynum2; i ++)
				{
					tmpstr[i] = a[i] + "";
				}
				//���������request
				
				Map<String,String> date_num = new LinkedHashMap<>();
				for(int i = 0; i < daynum2; i ++)
				{
					date_num.put(date4[i], tmpstr[i]);
					
				}
				
				request.setAttribute("date_num", date_num);
			
				
				/**
				 * ���ݴ��뱾��
				 */
				String path = request.getSession().getServletContext().getRealPath("/");
				FileOutputStream fop = null;
				String filename = path +"/data.txt";
				File file = new File(filename);
				if (!file.exists()) {
					file.createNewFile();
				}
				BufferedWriter bw = new BufferedWriter(new FileWriter(file,false));
				try {
					bw.write(daynum2+" ");
					for(int i=0;i<daynum2;i++) {
						bw.write(a[i]+" ");
						//bw.flush();
					}
					bw.newLine();
					for(int i=0;i<daynum2;i++) {
						bw.write(date4[i]+" ");
						//bw.flush();
					}
					bw.flush();
				}catch(IOException e) {
					e.printStackTrace();
				} finally {
					bw.close();
					
				}
				
				
			}//ԤԼ���ݷ�������
			 
			 /***********************
			  * 
			  ***********************/
			
			/**
			 * ����exe�ļ�
			 */
			/*
			Runtime rn = Runtime.getRuntime();
			Process p = null;
			try {
				String path = request.getSession().getServletContext().getRealPath("/");
				System.out.println(path);
				p = rn.exec(path+"/exe.exe");
				System.out.println("������");
			} catch (Exception e) {
			  System.out.println("Error exec!");
			}
			  
			*/
			/**
			  * ���������
			  */
			
			request.getRequestDispatcher("doctViewOrder.jsp").forward(request, response);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

	public String parseToNormalTime(Date date)
	{
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal =Calendar.getInstance();
		//Date tmpdate = new Date();
		//tmpdate = sdf.parse(date.toString());
		cal.setTime(date);
		int y,m,d;
		y = cal.get(Calendar.YEAR);
		m = cal.get(Calendar.MONTH) + 1;
		d = cal.get(Calendar.DAY_OF_MONTH);
		String str = y + "-" + m + "-" + d;
		//etime = (Object)str;
		return str;
	}
}
