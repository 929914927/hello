package web;

import tools.DBTools;
import tools.DtoTools;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ��ȡҳ�����ݴ���dto
		 */
		HttpSession session = request.getSession();
		Map<String, Object>dto = null;
		DtoTools dtotools = new DtoTools();
		dto = dtotools.createDto(request);
		/**
		 * �������ݿ�
		 */
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = DBTools.getConnection();
			StringBuilder sql = new StringBuilder();
			int flag = Integer.parseInt(dto.get("usetype").toString());
			if(flag==1)
			{
				sql.append("select *")
				.append(" from doctor")
				.append(" where phone=? and password=?");
			}
			if(flag == 2)
			{
				sql.append("select *")
				.append(" from patient")
				.append(" where phone=? and password=?");
			}
			if(flag == 3)
			{
				sql.append("select *")
				.append(" from admin")
				.append(" where phone=? and password=?");
			}
			
			pstm = conn.prepareStatement(sql.toString());
			pstm.setObject(1, dto.get("user"));
			pstm.setObject(2, dto.get("password"));
			rs = pstm.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int count = rsmd.getColumnCount();
			Map<String,String>ins = new HashMap<>();
			if(rs.next())
			{
				for(int i = 1; i <= count; i ++)
				{
					ins.put(rsmd.getColumnLabel(i), rs.getString(i));
				}
				request.setAttribute("msg", rs.getString(2));
				session.setAttribute("useid", rs.getString(1));
				String location = null;
				if(flag == 1)
					location = "doctorIndex.jsp";
				if(flag == 2)
					location = "patientIndex.jsp";
				if(flag == 3)
					location = "adminIndex.jsp";
				request.getRequestDispatcher(location).forward(request, response);
				
			}
			else
			{
				request.setAttribute("msg", "���޴��ˣ����������룡");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}finally {
			DBTools.close(rs, pstm, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
