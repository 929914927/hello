/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50640
Source Host           : localhost:3306
Source Database       : hoqs

Target Server Type    : MYSQL
Target Server Version : 50640
File Encoding         : 65001

Date: 2018-07-08 21:01:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` int(15) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('3', '10001', '10001', 'admin', '男', '2009-03-11', '22');

-- ----------------------------
-- Table structure for appointment
-- ----------------------------
DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime(6) DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(6),
  `patient_id` int(20) DEFAULT NULL,
  `doctor_id` int(20) DEFAULT NULL,
  `doctor_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `doctor_name` (`doctor_name`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appointment_ibfk_3` FOREIGN KEY (`doctor_name`) REFERENCES `doctor` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of appointment
-- ----------------------------
INSERT INTO `appointment` VALUES ('1', '2018-07-04 21:12:42.000000', '1', '2', '李四');
INSERT INTO `appointment` VALUES ('2', '2018-07-11 21:13:16.000000', '3', '4', '王五');
INSERT INTO `appointment` VALUES ('3', '2018-07-24 21:13:49.000000', '4', '5', '李华');
INSERT INTO `appointment` VALUES ('4', '2018-07-06 13:28:00.457740', '4', '1', '李华');
INSERT INTO `appointment` VALUES ('6', '2018-07-07 09:50:41.000000', '1', '1', '张三');

-- ----------------------------
-- Table structure for doctor
-- ----------------------------
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` int(15) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of doctor
-- ----------------------------
INSERT INTO `doctor` VALUES ('1', '20001', '20001', '张三', '普通', '内科', '男', '2018-06-05', '12');
INSERT INTO `doctor` VALUES ('2', '20002', '20002', '李四', '专家', '内科', '女', '2018-07-10', '23');
INSERT INTO `doctor` VALUES ('3', '20003', '20003', '王五', '普通', '外科', '男', '2018-07-02', '34');
INSERT INTO `doctor` VALUES ('4', '20004', '20004', '李华', '专家', '外科', '女', '2018-07-02', '37');
INSERT INTO `doctor` VALUES ('5', '20005', '20005', '张光', '专家', '内科', '男', '2018-07-02', '21');
INSERT INTO `doctor` VALUES ('14', '20012', '123', '123', '护士长', '神经外科', '1', '2018-07-06', '0');

-- ----------------------------
-- Table structure for patient
-- ----------------------------
DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` int(15) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of patient
-- ----------------------------
INSERT INTO `patient` VALUES ('1', '30001', '30001', '曹四', '男', '2018-07-04', '25');
INSERT INTO `patient` VALUES ('2', '30002', '30002', '王五', '女', '2018-06-05', '36');
INSERT INTO `patient` VALUES ('3', '30003', '30003', '田六', '女', '2018-05-15', '21');
INSERT INTO `patient` VALUES ('4', '30004', '30004', '闫八', '女', '2018-05-01', '36');
INSERT INTO `patient` VALUES ('5', '30005', '30005', '谢九', '男', '2018-04-17', '33');
INSERT INTO `patient` VALUES ('6', '15154', 'asdfg', '54321', '1', '2018-07-01', '45');
INSERT INTO `patient` VALUES ('8', '123', 'pmsrx12134', 'eandei', '1', '2018-07-12', '23');
INSERT INTO `patient` VALUES ('10', '15154', '123456', '123456', '1', '2018-07-03', '34');
INSERT INTO `patient` VALUES ('12', '30001', '123', '30001', '1', '2018-07-06', '0');
INSERT INTO `patient` VALUES ('13', '123', '123', '王', '1', '2018-07-06', '0');

-- ----------------------------
-- Table structure for work
-- ----------------------------
DROP TABLE IF EXISTS `work`;
CREATE TABLE `work` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(20) DEFAULT NULL,
  `worktime_start` time DEFAULT NULL,
  `worktime_end` time DEFAULT NULL,
  `appo_num` int(20) DEFAULT NULL,
  `curr_appo_num` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `work_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of work
-- ----------------------------
INSERT INTO `work` VALUES ('1', '1', '22:00:00', '06:00:00', '100', '21');
INSERT INTO `work` VALUES ('2', '2', '06:00:00', '12:00:00', '150', '30');
INSERT INTO `work` VALUES ('3', '3', '12:00:00', '18:00:00', '120', '10');
INSERT INTO `work` VALUES ('4', '4', '18:00:00', '22:00:00', '60', '5');
INSERT INTO `work` VALUES ('5', '5', '00:00:00', '06:00:00', '75', '10');
SET FOREIGN_KEY_CHECKS=1;
